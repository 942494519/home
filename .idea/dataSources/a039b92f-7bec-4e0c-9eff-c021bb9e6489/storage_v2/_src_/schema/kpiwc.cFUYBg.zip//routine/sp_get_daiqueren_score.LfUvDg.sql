create procedure sp_get_daiqueren_score(IN in_id int, OUT result_score varchar(50))
  BEGIN
	/*合计*/
DECLARE max_scores NUMERIC(8, 2);
/*处理中*/
DECLARE chuli_scores NUMERIC(8, 2);
/*复议中（审核中）*/
DECLARE fuyi_shenhe_scores NUMERIC(8, 2);
/*合计*/
SELECT ass_max INTO max_scores FROM assessment WHERE assessmentid=in_id LIMIT 1;
/*处理中*/
SELECT COALESCE(SUM(score),0) INTO chuli_scores FROM score WHERE ass_id=in_id AND ass_status=1;
/*复议中（审核中）*/
SELECT SUM(b.score) INTO fuyi_shenhe_scores FROM reply a,score b
WHERE a.replyid=b.replyid
AND a.reply_status=1
AND b.ass_id=in_id AND b.ass_status=4;
SET result_score=IFNULL(chuli_scores,0)+IFNULL(fuyi_shenhe_scores,0);
SELECT max_scores,chuli_scores,fuyi_shenhe_scores,result_score;
/*select result_score;*/
END;

