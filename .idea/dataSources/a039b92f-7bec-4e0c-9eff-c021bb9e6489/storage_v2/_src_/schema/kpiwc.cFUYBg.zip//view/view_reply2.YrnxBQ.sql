create view view_reply2 as
  select `kpiwc`.`reply`.`scoreid`        AS `scoreid`,
         `kpiwc`.`reply`.`reply_checkby`  AS `reply_checkby`,
         `kpiwc`.`reply`.`reply_createby` AS `reply_createby`
  from (`kpiwc`.`reply` join `kpiwc`.`replyd` on ((`kpiwc`.`reply`.`replyid` = `replyd`.`replyid`)));

