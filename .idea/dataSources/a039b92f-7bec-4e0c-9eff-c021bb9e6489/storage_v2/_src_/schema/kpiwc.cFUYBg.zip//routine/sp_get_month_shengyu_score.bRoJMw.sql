create procedure sp_get_month_shengyu_score(IN in_id int, OUT result_score varchar(50))
  BEGIN
	/*年*/
DECLARE belong_year_s VARCHAR(20);
/*月*/
DECLARE belong_month_s VARCHAR(20);
/*合计*/
DECLARE max_scores NUMERIC(8, 2);
/*处理中*/
DECLARE chuli_scores NUMERIC(8, 2);
/*已通过*/
DECLARE tongguo_scores NUMERIC(8, 2);
/*复议中（审核中）*/
DECLARE fuyi_shenhe_scores NUMERIC(8, 2);
/*通过（同意）*/
DECLARE tongguo_tongyi_scores NUMERIC(8, 2);
/*剩余值*/
DECLARE shengyu_scores NUMERIC(8, 2);
/*合计*/
SELECT ass_month,belong_year,belong_month INTO max_scores,belong_year_s,belong_month_s FROM assessment WHERE assessmentid=in_id LIMIT 1;
/*处理中*/
SELECT COALESCE(SUM(score),0) INTO chuli_scores FROM score WHERE ass_id=in_id AND ass_status=1 AND belong_year=belong_year_s AND belong_month=belong_month_s;
/*已通过*/
SELECT SUM(score) INTO tongguo_scores FROM score WHERE ass_id=in_id AND ass_status=2 AND belong_year=belong_year_s AND belong_month=belong_month_s;
/*复议中（审核中）*/
SELECT SUM(b.score) INTO fuyi_shenhe_scores FROM reply a,score b
WHERE a.replyid=b.replyid
AND a.reply_status=1
AND b.ass_id=in_id AND b.ass_status=4
AND b.belong_year=belong_year_s AND b.belong_month=belong_month_s;
/*通过（同意）*/
SELECT SUM(b.score) INTO tongguo_tongyi_scores FROM reply a,score b 
WHERE a.replyid=b.replyid AND a.reply_status=2 
AND b.ass_id=in_id AND b.ass_status=2
AND b.belong_year=belong_year_s AND b.belong_month=belong_month_s;

SET shengyu_scores = IFNULL(max_scores,0)-IFNULL(chuli_scores,0)-IFNULL(tongguo_scores,0)-IFNULL(fuyi_shenhe_scores,0)-IFNULL(tongguo_tongyi_scores,0);
SET result_score=shengyu_scores;
SELECT belong_year_s,belong_month_s,max_scores,chuli_scores,tongguo_scores,fuyi_shenhe_scores,tongguo_tongyi_scores,shengyu_scores,result_score;
/*select result_score;*/
END;

