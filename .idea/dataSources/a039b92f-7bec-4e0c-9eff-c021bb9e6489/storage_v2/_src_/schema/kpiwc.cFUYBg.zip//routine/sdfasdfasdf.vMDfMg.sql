create function sdfasdfasdf()
  returns int
  BEGIN
	#Routine body goes here...

	RETURN 0;
END;

