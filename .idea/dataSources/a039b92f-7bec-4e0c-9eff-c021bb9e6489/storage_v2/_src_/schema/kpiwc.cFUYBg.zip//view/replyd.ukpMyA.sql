create view replyd as
  select `kpiwc`.`score`.`replyid` AS `replyid`
  from `kpiwc`.`score`
  where (`kpiwc`.`score`.`scoreid` in
         (select `kpiwc`.`reply`.`scoreid` from `kpiwc`.`reply` where (`kpiwc`.`reply`.`reply_status` = 2)) and
         (`kpiwc`.`score`.`score` = '0.0') and (year(`kpiwc`.`score`.`createtime`) = 2015) and
         (month(`kpiwc`.`score`.`createtime`) in (1, 2, 3, 4)) and (`kpiwc`.`score`.`isreply` = 1) and
         (`kpiwc`.`score`.`dkid` = 0));

